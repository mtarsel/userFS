#ifndef UFS_H
#define UFS_H

int virtual_disk;
int u_quota();

#define DISK_LBA int //basically the location within the file to seek too

#endif
